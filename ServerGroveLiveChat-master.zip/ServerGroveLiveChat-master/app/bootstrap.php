<?php

require_once __DIR__.'/../vendor/symfony/src/Symfony/Component/HttpKernel/bootstrap.php';
require_once __DIR__.'/autoload.php';
