<?php

namespace ServerGrove\SGLiveChatBundle\Cache\Engine;

use ServerGrove\SGLiveChatBundle\Cache\Cacheable;

/**
 * Description of Base
 *
 * @author Ismael Ambrosi<ismael@servergrove.com>
 */
abstract class Base implements Cacheable
{

}